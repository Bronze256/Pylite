# PyLite Team 5 — Tooling, CLI Integration & Tests

This package provides:
- CLI: `python -m pylite lex script.lite`
- Human-readable token table / token visualizer
- JSON token export
- Automated tests with `unittest`
- Friendly lexical-error output with line and column

## Run it

Use Python 3.10+ and open a terminal in this folder.

```bash
python -m pylite lex examples/hello.lite
python -m pylite lex examples/hello.lite --json tokens.json
python -m pylite lex examples/hello.lite --json-only
python -m unittest discover -s tests -v
```

## Example `.lite` file

```text
let count = 1
count = count + 1
print("Hello PyLite")
```

## JSON token format

Each token is exported as an object containing:
`type`, `lexeme`, `line`, `column`, and `index`.

## Integrating Teams 1–4

The included `pylite/lexer.py` is a small reference lexer so Team 5 can run and demonstrate the tooling immediately. When the shared lexer is ready, update the import in `pylite/cli.py` to use the team's `LexerEngine` and adapt its token objects in `token_dict()`. The expected token information is type, lexeme, line, column, and character index. If your team's token class uses different field names, map them in `token_dict()`.

## Exit codes

- `0`: success
- `1`: lexical error
- `2`: file read/write or CLI error
