"""Command-line tools for the PyLite lexer."""
import argparse
import json
import sys
from dataclasses import asdict, is_dataclass
from pathlib import Path

from .lexer import Lexer, LexError


def token_dict(token):
    if hasattr(token, "to_dict"):
        return token.to_dict()
    if is_dataclass(token):
        return asdict(token)
    if isinstance(token, dict):
        return token
    fields = ("type", "lexeme", "line", "column", "index")
    return {key: getattr(token, key) for key in fields if hasattr(token, key)}


def format_tokens(tokens):
    headers = ("TYPE", "LEXEME", "LINE", "COL", "INDEX")
    rows = []
    for token in tokens:
        item = token_dict(token)
        rows.append([
            str(item.get("type", "")),
            repr(item.get("lexeme", "")),
            str(item.get("line", "")),
            str(item.get("column", "")),
            str(item.get("index", "")),
        ])
    widths = [max(len(headers[i]), *(len(row[i]) for row in rows)) if rows else len(headers[i])
              for i in range(len(headers))]
    line = "  ".join(headers[i].ljust(widths[i]) for i in range(len(headers)))
    sep = "  ".join("-" * widths[i] for i in range(len(headers)))
    body = ["  ".join(row[i].ljust(widths[i]) for i in range(len(headers))) for row in rows]
    return "\n".join([line, sep, *body])


def main(argv=None):
    parser = argparse.ArgumentParser(prog="pylite", description="PyLite lexer tooling")
    sub = parser.add_subparsers(dest="command", required=True)
    lex_parser = sub.add_parser("lex", help="tokenize a .lite file")
    lex_parser.add_argument("file", type=Path, help="source .lite file")
    lex_parser.add_argument("--json", dest="json_path", type=Path,
                            help="also export tokens to this JSON file")
    lex_parser.add_argument("--json-only", action="store_true",
                            help="print JSON to stdout instead of the token table")
    args = parser.parse_args(argv)

    try:
        source = args.file.read_text(encoding="utf-8")
    except OSError as exc:
        print(f"PyLite CLI error: cannot read '{args.file}': {exc}", file=sys.stderr)
        return 2

    try:
        tokens = Lexer(source).tokenize()
    except LexError as exc:
        print(f"PyLite LexError [Line {exc.line}, Col {exc.column}]: {exc.message}.",
              file=sys.stderr)
        if exc.source_line:
            print(f"{exc.line} | {exc.source_line}", file=sys.stderr)
            print("    " + " " * max(0, exc.column - 1) + "^", file=sys.stderr)
        return 1

    serializable = [token_dict(token) for token in tokens]
    if args.json_path:
        try:
            args.json_path.write_text(json.dumps(serializable, indent=2), encoding="utf-8")
        except OSError as exc:
            print(f"PyLite CLI error: cannot write JSON: {exc}", file=sys.stderr)
            return 2

    if args.json_only:
        print(json.dumps(serializable, indent=2))
    else:
        print(format_tokens(tokens))
        if args.json_path:
            print(f"\nJSON exported to: {args.json_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
