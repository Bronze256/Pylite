"""Small reference lexer used to make Team 5 tooling runnable.

Replace Lexer.tokenize() with an adapter to the combined lexer from Teams 1–4
when that implementation is ready. Token objects expose type, lexeme, line,
column, and index.
"""
from dataclasses import dataclass, asdict
import re


@dataclass
class Token:
    type: str
    lexeme: str
    line: int
    column: int
    index: int

    def to_dict(self):
        return asdict(self)


KEYWORDS = {
    "let": "LET", "const": "CONST", "if": "IF", "unless": "UNLESS",
    "repeat": "REPEAT", "times": "TIMES", "end": "END", "print": "PRINT",
    "true": "TRUE", "false": "FALSE",
}
TWO_CHAR = {"|>": "PIPE", "==": "EQUAL_EQUAL", "!=": "BANG_EQUAL",
            "<=": "LESS_EQUAL", ">=": "GREATER_EQUAL"}
ONE_CHAR = {"=": "EQUAL", "+": "PLUS", "-": "MINUS", "*": "STAR",
            "/": "SLASH", "<": "LESS", ">": "GREATER", ":": "COLON",
            "(": "LEFT_PAREN", ")": "RIGHT_PAREN", ",": "COMMA"}


class LexError(Exception):
    def __init__(self, message, line, column, source_line=""):
        super().__init__(message)
        self.message, self.line, self.column = message, line, column
        self.source_line = source_line


class Lexer:
    def __init__(self, source):
        self.source = source

    def tokenize(self):
        src = self.source
        tokens = []
        i, line, col = 0, 1, 1

        def add(kind, start, end, token_line, token_col):
            tokens.append(Token(kind, src[start:end], token_line, token_col, start))

        while i < len(src):
            ch = src[i]
            if ch in " \r":
                i += 1; col += 1
                continue
            if ch == "\t":
                i += 1; col += 4
                continue
            if ch == "\n":
                i += 1; line += 1; col = 1
                continue
            if ch == "#":
                while i < len(src) and src[i] != "\n":
                    i += 1; col += 1
                continue

            start, token_line, token_col = i, line, col

            if ch == '"':
                i += 1; col += 1
                escaped = False
                while i < len(src):
                    c = src[i]
                    if c == "\n" and not escaped:
                        raise LexError("Unclosed string literal detected", token_line, token_col,
                                       src.splitlines()[token_line-1] if src.splitlines() else "")
                    if c == '"' and not escaped:
                        i += 1; col += 1
                        break
                    if c == "\\" and not escaped:
                        escaped = True
                    else:
                        escaped = False
                    i += 1; col += 1
                else:
                    line_text = src.splitlines()[token_line-1] if src.splitlines() else ""
                    raise LexError("Unclosed string literal detected", token_line, token_col, line_text)
                add("STRING", start, i, token_line, token_col)
                continue

            if ch.isdigit():
                i += 1; col += 1
                while i < len(src) and src[i].isdigit():
                    i += 1; col += 1
                add("INTEGER", start, i, token_line, token_col)
                continue

            if ch.isalpha() or ch == "_":
                i += 1; col += 1
                while i < len(src) and (src[i].isalnum() or src[i] == "_"):
                    i += 1; col += 1
                word = src[start:i]
                add(KEYWORDS.get(word, "IDENTIFIER"), start, i, token_line, token_col)
                continue

            pair = src[i:i+2]
            if pair in TWO_CHAR:
                i += 2; col += 2
                add(TWO_CHAR[pair], start, i, token_line, token_col)
                continue
            if ch in ONE_CHAR:
                i += 1; col += 1
                add(ONE_CHAR[ch], start, i, token_line, token_col)
                continue

            line_text = src.splitlines()[line-1] if src.splitlines() else ""
            raise LexError(f"Unexpected character {ch!r}", line, col, line_text)

        tokens.append(Token("EOF", "", line, col, len(src)))
        return tokens
