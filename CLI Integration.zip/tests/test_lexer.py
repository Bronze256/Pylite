import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from pylite.lexer import Lexer, LexError
from pylite.cli import format_tokens


class LexerTests(unittest.TestCase):
    def kinds(self, source):
        return [token.type for token in Lexer(source).tokenize()]

    def test_empty_file_has_eof(self):
        tokens = Lexer("").tokenize()
        self.assertEqual(len(tokens), 1)
        self.assertEqual(tokens[0].type, "EOF")

    def test_keywords_and_identifier(self):
        self.assertEqual(self.kinds("let score = 42"),
                         ["LET", "IDENTIFIER", "EQUAL", "INTEGER", "EOF"])

    def test_greedy_multi_character_operators(self):
        self.assertEqual(self.kinds("a |> f == b != c <= d >= e"),
                         ["IDENTIFIER", "PIPE", "IDENTIFIER", "EQUAL_EQUAL",
                          "IDENTIFIER", "BANG_EQUAL", "IDENTIFIER", "LESS_EQUAL",
                          "IDENTIFIER", "GREATER_EQUAL", "IDENTIFIER", "EOF"])

    def test_string_literal(self):
        tokens = Lexer('print("Hello World")').tokenize()
        self.assertEqual(tokens[2].type, "STRING")
        self.assertEqual(tokens[2].lexeme, '"Hello World"')

    def test_comment_is_ignored(self):
        self.assertEqual(self.kinds("let x = 1 # comment\nprint(x)"),
                         ["LET", "IDENTIFIER", "EQUAL", "INTEGER", "PRINT",
                          "LEFT_PAREN", "IDENTIFIER", "RIGHT_PAREN", "EOF"])

    def test_line_and_column_tracking(self):
        tokens = Lexer("let x = 1\n  print(x)").tokenize()
        print_token = next(t for t in tokens if t.type == "PRINT")
        self.assertEqual(print_token.line, 2)
        self.assertEqual(print_token.column, 3)

    def test_unclosed_string_raises_lex_error(self):
        with self.assertRaises(LexError) as ctx:
            Lexer('let message = "Hello World').tokenize()
        self.assertEqual(ctx.exception.message, "Unclosed string literal detected")
        self.assertEqual(ctx.exception.line, 1)

    def test_invalid_character_raises_lex_error(self):
        with self.assertRaises(LexError):
            Lexer("let x = @").tokenize()

    def test_large_string(self):
        text = "a" * 100_000
        token = Lexer('"' + text + '"').tokenize()[0]
        self.assertEqual(len(token.lexeme), 100_002)

    def test_token_visualizer(self):
        rendered = format_tokens(Lexer("let x = 1").tokenize())
        self.assertIn("TYPE", rendered)
        self.assertIn("IDENTIFIER", rendered)
        self.assertIn("EOF", rendered)


class CLITests(unittest.TestCase):
    def test_cli_table_and_json_export(self):
        with tempfile.TemporaryDirectory() as folder:
            source = Path(folder) / "sample.lite"
            output = Path(folder) / "tokens.json"
            source.write_text("let x = 7", encoding="utf-8")
            result = subprocess.run(
                [sys.executable, "-m", "pylite", "lex", str(source), "--json", str(output)],
                cwd=ROOT, capture_output=True, text=True
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("IDENTIFIER", result.stdout)
            data = json.loads(output.read_text(encoding="utf-8"))
            self.assertEqual(data[0]["type"], "LET")
            self.assertEqual(data[-1]["type"], "EOF")

    def test_cli_json_only(self):
        with tempfile.TemporaryDirectory() as folder:
            source = Path(folder) / "sample.lite"
            source.write_text("print(true)", encoding="utf-8")
            result = subprocess.run(
                [sys.executable, "-m", "pylite", "lex", str(source), "--json-only"],
                cwd=ROOT, capture_output=True, text=True
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            data = json.loads(result.stdout)
            self.assertEqual(data[0]["type"], "PRINT")

    def test_cli_reports_lexical_error(self):
        with tempfile.TemporaryDirectory() as folder:
            source = Path(folder) / "bad.lite"
            source.write_text('let message = "oops', encoding="utf-8")
            result = subprocess.run(
                [sys.executable, "-m", "pylite", "lex", str(source)],
                cwd=ROOT, capture_output=True, text=True
            )
            self.assertEqual(result.returncode, 1)
            self.assertIn("PyLite LexError", result.stderr)
            self.assertIn("Unclosed string literal", result.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
